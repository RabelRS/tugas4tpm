import 'package:flutter/material.dart';

class MemberListPage extends StatelessWidget {

  final List<Map<String, String>> members = [
    {'name': 'Rabel Octadian Jhonifer', 'nim': '123210176'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Anggota'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
        ),
      ),
      body: ListView.builder(
        itemCount: members.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(members[index]['name']!),
              subtitle: Text('NIM: ${members[index]['nim']}'),
            ),
          );
        },
      ),
    );
  }
}
