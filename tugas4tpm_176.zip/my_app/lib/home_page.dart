import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            _buildMenuButton(context, 'Daftar Anggota', '/memberList', Icons.people),
            SizedBox(height: 16),
            _buildMenuButton(context, 'Aplikasi Bilangan Prima', '/primeNumber', Icons.filter_list),
            SizedBox(height: 16),
            _buildMenuButton(context, 'Penghitung Luas dan Keliling Segitiga', '/triangleCalculator', Icons.aspect_ratio),
            SizedBox(height: 16),
            _buildMenuButton(context, 'Daftar Situs Rekomendasi', '/recommendationSites', Icons.web),
            SizedBox(height: 16),
            _buildMenuButton(context, 'Favorite', '/favorites', Icons.favorite),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuButton(BuildContext context, String label, String route, IconData icon) {
    return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
        onPressed: () {
      Navigator.pushNamed(context, route);
    },
    icon: Icon(icon),
    label: Text(label),
    style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
    padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.symmetric(vertical: 16)),
    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
    borderRadius:
    ),
    ),
    ),
        ),
    );
  }
}

