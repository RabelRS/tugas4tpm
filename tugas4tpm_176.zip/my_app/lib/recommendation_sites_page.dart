import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class RecommendationSitesPage extends StatelessWidget {
  final List<Map<String, String>> sites = [
    {
      'name': 'Google',
      'url': 'https://www.google.com',
      'image': 'https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png'
    },
    {
      'name': 'Flutter',
      'url': 'https://flutter.dev',
      'image': 'https://flutter.dev/assets/images/shared/brand/flutter/logo/flutter-lockup.png'
    },
  ];

  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Situs Rekomendasi'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
        ),
      ),
      body: ListView.builder(
        itemCount: sites.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              leading: Image.network(sites[index]['image']!, width: 50, height: 50),
              title: Text(sites[index]['name']!),
              onTap: () => _launchURL(sites[index]['url']!),
            ),
          );
        },
      ),
    );
  }
}
