import 'package:flutter/material.dart';

class TriangleCalculatorPage extends StatefulWidget {
  @override
  _TriangleCalculatorPageState createState() => _TriangleCalculatorPageState();
}

class _TriangleCalculatorPageState extends State<TriangleCalculatorPage> {
  final TextEditingController _baseController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _sideAController = TextEditingController();
  final TextEditingController _sideBController = TextEditingController();
  final TextEditingController _sideCController = TextEditingController();

  String _areaResult = '';
  String _perimeterResult = '';

  void _calculate() {
    double base = double.tryParse(_baseController.text) ?? 0;
    double height = double.tryParse(_heightController.text) ?? 0;
    double sideA = double.tryParse(_sideAController.text) ?? 0;
    double sideB = double.tryParse(_sideBController.text) ?? 0;
    double sideC = double.tryParse(_sideCController.text) ?? 0;

    double area = 0.5 * base * height;
    double perimeter = sideA + sideB + sideC;

    setState(() {
      _areaResult = 'Luas Segitiga: $area';
      _perimeterResult = 'Keliling Segitiga: $perimeter';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Penghitung Luas dan Keliling Segitiga'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _baseController,
              decoration: InputDecoration(labelText: 'Alas Segitiga'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _heightController,
              decoration: InputDecoration(labelText: 'Tinggi Segitiga'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _sideAController,
              decoration: InputDecoration(labelText: 'Sisi A Segitiga'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _sideBController,
              decoration: InputDecoration(labelText: 'Sisi B Segitiga'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _sideCController,
              decoration: InputDecoration(labelText: 'Sisi C Segitiga'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _calculate,
              child: Text('Hitung'),
            ),
            SizedBox(height: 20),
            Text(
              _areaResult,
              style: TextStyle(fontSize: 18),
            ),
            Text(
              _perimeterResult,
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
